#!/bin/bash
clear
vers=1.2.9
dat=04.05.2019


if ! [ -d ~/.HHSW/autopicture ]
	then
	echo "Bitte installiere AutoPicture (Minimum V.1.2.8)"
	echo "Update abgebrochen!"
	sleep 5
else

	echo
	echo ==============================================
	echo =
	echo + Willkommen zur Update-Installation
	echo + von AutoPicture V$vers vom $dat
	echo =
	echo ==============================================
	echo
		whoami > .user.txt

            while read line
            do
            	user=$line
            	pcuser=/home/$user
            done < .user.txt
		pwd > .ich.txt            
            while read line
            do
            	ich=$line
            done < .ich.txt
            
	rm -rf .user.txt
	rm -rf .ich.txt
	home=$pcuser/.HHSW/autopicture/AutoPicture
	ini=$pcuser/.HHSW/autopicture

		while read line
		do
			ver_a=$line
		done < $ini/.ver.txt

		echo Update von V. $ver_a zu $vers
		sleep 2

	echo $vers > $ini/.ver.txt
	echo $dat > $ini/.dat.txt
	q=$ich/.updata
	cd $q
	ls > $ich/.list.txt
	wc -l $ich/.list.txt > $ich/.zeilen.txt
	rm -rf $ich/.list.txt
	cut -d " " -f1 $ich/.zeilen.txt > $ich/.z.txt
		while read line
		do
			z=$line
		done < $ich/.z.txt
		rm -rf $ich/Schreibtisch/AutoPicture.sh
	run(){
		#rename 's/\s/_/g' *
		ls > $ich/.list.txt
		head -n 1 $ich/.list.txt > $ich/.data.txt

        while read zeile
        do
        datei=$zeile
        done < $ich/.data.txt
        rm -rf $home/$datei
        mv -f $q/$datei $home >> $ich/.cp.txt
	}

		for ((k=1; k <= $z; k++)); do
			run
		done
		mv $home/AutoPicture.sh $ich/Schreibtisch  >> $ich/.cp.txt

		delete(){
			rm -rf $ich/.user.txt
			rm -rf $ich/.ich.txt
			rm -rf $ich/.zeilen.txt
			rm -rf $ich/.data.txt
			rm -rf $ich/.list.txt
			rm -rf $ich/.cp.txt
			rm -rf $ich/.z.txt
		}

	echo "Update abgeschlossen"
	delete
	sleep 2
	rm -rf $ich
fi
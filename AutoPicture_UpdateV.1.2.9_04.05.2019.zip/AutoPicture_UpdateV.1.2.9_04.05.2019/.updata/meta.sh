#!/bin/bash
#Geht in den Stamm-Ordner
ty=0
cd ~/.HHSW/autopicture
            #Belet alle nötigen Var.
            while read line
            do
            home=$line
            done < .home.txt
            
            while read line
            do
            quelle=$line
            done < .quelle.txt
            
            while read line
            do
            ziel=$line
            done < .ziel.txt
            
            while read line
            do
            log=$line
            done < .log.txt

            while read line
            do
            vers=$line
            done < .ver.txt



mkdir -p $home/.LogData #macht den LogData Ordner
 cd $quelle
 rename 's/\s/_/g' *
 ls > $log/log.txt  

 wc -l $log/log.txt > $log/zeilen.txt   #Zählt die Dateien

 cut -d " " -f1 $log/zeilen.txt > $log/z.txt    #macht die zahl der Dateien zur Verarbeitung bereit

#Belegt die Var. mit dem Datum únd der Uhrzeit

 datum=`date +%d.%m.%Y`
 zeit=`date +%H:%M:%S`

 echo $datum um $zeit Uhr >> $home/protokoll.txt    #schreibt das Datum in das Protokoll
 sleep 2
 sortieren(){   #Function "sortieren"

 cd $quelle
 ls > $log/log.txt

 #___________________________________________________________________

#Wenn das Datum im exif nicht gefunden


erro_a(){

	#if [ -z "$gp" ] #Wenn 'Create Date' nicht gefunden, mache dies
	   
	   if [[ "$filetyp" = *wmv* ]]
		  then
          
		  grep -rnwi $log/exif.txt -e 'Creation Date' > $log/gp.txt
        fi

        if [ -z "$gp" ]
            then
            ty=$((ty +1))
            grep -rnwi $log/exif.txt -e 'File Modification Date/Time' > $log/gp.txt
        fi
}

erro_b(){
    if [[ "$jahr" = *0000* ]]
        then
        mv -v $quelle/$datei $ziel/Ohne_Datum/ >> $home/protokoll.txt
    else
        mkdir -p $ziel/$jahr/$monat/$tage/     #erstellt die Ordner (-p damit, wenn das Verzeichniss bereit da ist kein Fehler auftritt.)
        mv -v $quelle/$datei $ziel/$jahr/$monat/$tage/ >> $home/protokoll.txt
    fi
}


 head -n 1 $log/log.txt > $log/data.txt     #Sucht sich das erste Bild raus

        while read zeile
        do
        datei=$zeile
        done < $log/data.txt

 exiftool $datei > $log/exif.txt    #schaut in die MetaDaten und Speichert sie in exif.txt
        while read zeile
        do
        meta=$zeile
        done < $log/exif.txt



 grep -rnwi $log/exif.txt -e 'File Type Extension' > $log/filet.txt     #Guckt, was für ein Format diese datei hat
 cut -c 37-40 $log/filet.txt > $log/filetyp.txt
 while read line
 do
 	filetyp=$line
 done < $log/filetyp.txt

 grep -rnwi $log/exif.txt -e 'Create Date' > $log/gp.txt    #Sucht sich das Datum raus
 while read line
 do
 	gp=$line
 done < $log/gp.txt

 erro_a #Function "error_a"

#macht das Datum lesbar für die Weitere Verarbeitung

    case $ty in
        "0")
        cut -c 38-47 $log/gp.txt > $log/datum.txt
        ;;

        "1")
        cut -c 37-46 $log/gp.txt > $log/datum.txt
        ty=$((ty -1))
        ;;
    esac
        cut -c 1-4 $log/datum.txt > $log/jahr.txt
        cut -c 6-7 $log/datum.txt > $log/monat.txt
        cut -c 9-10 $log/datum.txt > $log/tag.txt
       


            while read zeile
            do
            jahr=$zeile
            done < $log/jahr.txt

            while read zeile
            do
            monat=$zeile
            done < $log/monat.txt

            while read zeile
            do
            tage=$zeile
            done < $log/tag.txt

            erro_b

 

}

while read line
do
z=$line
done < $log/z.txt

        
cd $home
if [ "$z" -eq "0" ] #Wenn Var. z leer, mache das (kein Bild im Temp. Ordner!)
	then
	echo "Es wurden keine Bilder oder Videos gefunden!"
else
    min=`date +%M` && sek=`date +%s`
	echo $z Bilder werden verschoben
		for ((k=1; k<= $z; k++)); do #Geht die schleife so oft, wie Bilder im Temp. Ordner sind

    		sortieren #Function "sortieren" 

            clear
            echo ':---------------------------------------------------------------------------':
            echo ':                           'AutoPicture V.$vers'                             ':
            echo ':                                                                           ':
            echo ':                                                                           ':
            echo ':                                                                           ':
    		echo ':                            'Datei $k von $z'                              '
            echo ':                                                                           ':
            echo ':                                                                           ':
            echo ':                                                                           ':
            echo ':---------------------------------------------------------------------------': 
		done

        min2=`date +%M` && sek2=`date +%s`

            echo ':                                 'Fertig!'                                   ':
            echo ':---------------------------------------------------------------------------':
fi

rm -rf $home/.LogData
sleep 5
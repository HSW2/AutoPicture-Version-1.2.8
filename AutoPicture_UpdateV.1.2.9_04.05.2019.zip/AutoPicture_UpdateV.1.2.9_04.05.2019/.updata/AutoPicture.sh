#!/bin/sh
clear
cd ~/.HHSW/autopicture

            while read line
            do
            home=$line
            done < .home.txt
            
            while read line
            do
            vers=$line
            done < .ver.txt
            
            while read line
            do
            dat=$line
            done < .dat.txt

            
cd $home
echo
echo ==================================================
echo =
echo + Willkommen bei AutoPicture
echo + Version V$vers vom $dat
echo =
echo + "Geschrieben von Hendrik Heine (HHSW)"
echo + "und Jens Ruckelshaeuser-Heine (JeruSoftWare)"
echo =
echo =================================================


mkdir -p .LogData
echo 
sleep 1
./meta.sh

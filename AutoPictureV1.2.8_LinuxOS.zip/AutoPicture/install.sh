#!/bin/bash
clear
vers=1.2.8
dat=02.05.2019

echo
echo ==============================================
echo =
echo + Willkommen zur Installation
echo + von AutoPicture V$vers vom $dat
echo =
echo ==============================================
echo
whoami > .user.txt

            while read line
            do
            user=$line
            pcuser=/home/$user
            done < .user.txt
pwd > .ich.txt            
            while read line
            do
            ich=$line
            done < .ich.txt
            
rm -rf .user.txt
rm -rf .ich.txt
mkdir -p $pcuser/.HHSW/autopicture
home=$pcuser/.HHSW/autopicture/AutoPicture
ini=$pcuser/.HHSW/autopicture
echo $vers > $ini/.ver.txt
echo $dat > $ini/.dat.txt
mv -v $ich $ini

echo $home/.LogData > $ini/.log.txt
cd $home
echo $home > $ini/.home.txt
echo
mv AutoPicture.sh $pcuser/Schreibtisch
spfadq=$pcuser/Bilder/TempPic
spfadz=$pcuser/Bilder/Kamera
echo Der Standart Pfad für den Temp. Bilderordner ist: $spfadq
echo Der Standart Pfad für den Ordner wo die Bilder rein sortiert werden ist: $spfadz
echo
echo Moechten sie die Standart Pfade benutzen oder die Benutzerdefinireten Pfade? s oder b?

read dia

case $dia in
    "b")
        echo Gib einen Temp. Ordner an, wo sich die Bilder befinden:
        echo ''
        echo $HOME 
        read line 
        echo $HOME/$line > $ini/.quelle.txt
        echo Gib einen Ordner an, wo die Bilder rein sortiert werden sollen:
        echo ''
        echo $HOME
        read line
        echo $HOME/$line > $ini/.ziel.txt
        mkdir -p $HOME/$line/Ohne_Datum
        ;;
    "s")
        echo Standart Pfade werden angelegt...
        echo $spfadq > $ini/.quelle.txt
        echo $spfadz > $ini/.ziel.txt
        mkdir -p $spfadq
        mkdir -p $spfadz
        mkdir -p $spfadz/Ohne_Datum
        ;;
esac
ln -s $home ~/Schreibtisch

echo
echo Installiere das Programm ExifTool.
echo Es ist für die Nutzung von AutoPicture notwendig
sudo apt-get install libimage-exiftool-perl perl-doc
sudo cp -v $home/AutoPicture_Icon /usr/share/icons
rm -rf $home/install.sh


#!/bin/bash

echo
echo ===================================
echo =
echo + Willkommen zur Deinstallation
echo + von AutoPicture
echo =
echo ===================================
echo ''
echo Moechten Sie die Software AutoPicture wirklich Deinstallieren? j oder n?
read dia

case $dia in
    "j")
        cd ~/Schreibtisch
        rm -rf AutoPicture.sh
        rm -rf AutoPicture
        cd ~/; rm -rf .HHSW/autopicture/
;;
        
    "n")
    echo Herzlich Willkommen zurueck
    sleep 2
esac


#!/bin/bash

clear
cd ~/.autopicture

            while read line
            do
            home=$line
            done < .home.txt
            
            while read line
            do
            vers=$line
            done < .ver.txt
            
            while read line
            do
            dat=$line
            done < .dat.txt

            while read line
            do
            quelle=$line
            done < .quelle.txt
            
            while read line
            do
            ziel=$line
            done < .ziel.txt
cd $home
echo
echo ==================================================
echo =
echo + Willkommen beim Setup von AutoPicture
echo + Version $vers vom $dat
echo =
echo + "Geschrieben von Hendrik Heine (HHSW)"
echo + "und Jens Ruckelshaeuser-Heine (JeruSoftWare)"
echo =
echo =================================================

echo ''
echo Hier koennen sie die Verzeichnisse ändern...
echo ''
echo Was wollen sie ändern?
echo =='Quelle(q)'
echo =='Ziel(z)'
echo =='Beides(b)'
echo ''
read line
case $line in
	"q")
		echo Geben sie eine neune Quelle ein:
		echo $HOME/
		read line
		echo $HOME/$line > ~/.autopicture/.quelle.txt
	;;
	"z")
		echo Geben sie ein neunes Ziel ein:
		echo $HOME/
		read line
		echo $HOME/$line > ~/.autopicture/.ziel.txt
	;;
	"b")
		echo Geben sie eine neune Quelle ein:
		echo $HOME/
		read line
		echo $HOME/$line > ~/.autopicture/.quelle.txt
		echo ''
		echo Geben sie ein neunes Ziel ein:
		echo $HOME/
		read line
		echo $HOME/$line > ~/.autopicture/.ziel.txt
	;;
esac
